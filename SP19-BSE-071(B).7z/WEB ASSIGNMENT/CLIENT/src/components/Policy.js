import React from "react";
import { Container, Row, Col } from "react-bootstrap";

const Policy = () => {
  return (
    <>
      <Container style={{ marginTop: "50px" }}>
        <h1>Terms and Conditions</h1>
        <Row>
          <Col md={10}>
            <h6>
              Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam
              euismod velit non ante posuere, non ultricies nulla bibendum.
              Morbi vehicula convallis quam, scelerisque consequat leo rhoncus
              sit amet. Donec a ante quis
            </h6>
            <p>
              Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam
              euismod velit non ante posuere, non ultricies nulla bibendum.
              Morbi vehicula convallis quam, scelerisque consequat leo rhoncus
              sit amet. Donec a ante quis lorem finibus lobortis sit amet vel
              tellus. Nullam fermentum odio ut magna venenatis, non mattis orci
              pellentesque. Donec finibus sed nibh non interdum. Maecenas
              vestibulum fermentum quam aliquam aliquam. Quisque in augue
              ultrices, lacinia odio a, varius ex. Phasellus laoreet nisi in
              semper dignissim. In dapibus semper felis, non rutrum ex pulvinar
              a. Orci varius natoque penatibus et magnis dis parturient montes,
              nascetur ridiculus mus. Quisque ornare velit.
            </p>
            <h6>
              Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam
              euismod velit non ante posuere, non ultricies nulla bibendum.
              Morbi vehicula convallis quam, scelerisque consequat leo rhoncus
              sit amet. Donec a ante quis
            </h6>
            <p>
              Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam
              euismod velit non ante posuere, non ultricies nulla bibendum.
              Morbi vehicula convallis quam, scelerisque consequat leo rhoncus
              sit amet. Donec a ante quis lorem finibus lobortis sit amet vel
              tellus. Nullam fermentum odio ut magna venenatis, non mattis orci
              pellentesque. Donec finibus sed nibh non interdum. Maecenas
              vestibulum fermentum quam aliquam aliquam. Quisque in augue
              ultrices, lacinia odio a, varius ex. Phasellus laoreet nisi in
              semper dignissim. In dapibus semper felis, non rutrum ex pulvinar
              a. Orci varius natoque penatibus et magnis dis parturient montes,
              nascetur ridiculus mus. Quisque ornare velit.
            </p>
            <h6>
              Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam
              euismod velit non ante posuere, non ultricies nulla bibendum.
              Morbi vehicula convallis quam, scelerisque consequat leo rhoncus
              sit amet. Donec a ante quis
            </h6>
            <p>
              Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam
              euismod velit non ante posuere, non ultricies nulla bibendum.
              Morbi vehicula convallis quam, scelerisque consequat leo rhoncus
              sit amet. Donec a ante quis lorem finibus lobortis sit amet vel
              tellus. Nullam fermentum odio ut magna venenatis, non mattis orci
              pellentesque. Donec finibus sed nibh non interdum. Maecenas
              vestibulum fermentum quam aliquam aliquam. Quisque in augue
              ultrices, lacinia odio a, varius ex. Phasellus laoreet nisi in
              semper dignissim. In dapibus semper felis, non rutrum ex pulvinar
              a. Orci varius natoque penatibus et magnis dis parturient montes,
              nascetur ridiculus mus. Quisque ornare velit.
            </p>
            <h6>
              Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam
              euismod velit non ante posuere, non ultricies nulla bibendum.
              Morbi vehicula convallis quam, scelerisque consequat leo rhoncus
              sit amet. Donec a ante quis
            </h6>
            <p>
              Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam
              euismod velit non ante posuere, non ultricies nulla bibendum.
              Morbi vehicula convallis quam, scelerisque consequat leo rhoncus
              sit amet. Donec a ante quis lorem finibus lobortis sit amet vel
              tellus. Nullam fermentum odio ut magna venenatis, non mattis orci
              pellentesque. Donec finibus sed nibh non interdum. Maecenas
              vestibulum fermentum quam aliquam aliquam. Quisque in augue
              ultrices, lacinia odio a, varius ex. Phasellus laoreet nisi in
              semper dignissim. In dapibus semper felis, non rutrum ex pulvinar
              a. Orci varius natoque penatibus et magnis dis parturient montes,
              nascetur ridiculus mus. Quisque ornare velit.
            </p>
          </Col>
        </Row>
      </Container>
    </>
  );
};

export default Policy;
