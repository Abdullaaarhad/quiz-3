export const addToCart = (book, varient, quantity) => (dispatch, getState) => {
  var cartItem = {
    name: book.name,
    _id: book._id,
    image: book.image,
    varient: varient,
    quantity: quantity,
    prices: book.prices,
    price: book.price[0][varient] * quantity,
  };
  dispatch({ type: "ADD_TO_CART", payload: cartItem });
  localStorage.setItem(
    "cartItems",
    JSON.stringify(getState().cartReducer.cartItems)
  );
};
