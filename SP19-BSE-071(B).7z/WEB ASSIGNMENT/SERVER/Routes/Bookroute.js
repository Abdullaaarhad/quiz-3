const express = require("express");
const router = express.Router();
const bookModel = require("../models/bookModel");

router.get("./getAllBooks", async (req, res) => {
  try {
    const books = await bookModel.find({});
    res.send(books);
  } catch (error) {
    res.json({ message: error });
  }
});
module.exports = router;
