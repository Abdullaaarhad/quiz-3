import React from "react";
import { Container, Row, Col, Table, Image } from "react-bootstrap";
import { ImPhone } from "react-icons/im";
import { AiFillFacebook } from "react-icons/ai";
import { CgMail } from "react-icons/cg";

const Contact = () => {
  return (
    <>
      <Container style={{ marginTop: "50px" }}>
        <Row>
          <Col md={6}>
            <p>
              Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam
              euismod velit non ante posuere, non ultricies nulla bibendum.
              Morbi vehicula convallis quam, scelerisque consequat leo rhoncus
              sit amet. Donec a ante quis lorem finibus lobortis sit amet vel
              tellus. Nullam fermentum odio ut magna venenatis, non mattis orci
              pellentesque. Donec finibus sed nibh non interdum. Maecenas
              vestibulum fermentum quam aliquam aliquam. Quisque in augue
              ultrices, lacinia odio a, varius ex. Phasellus laoreet nisi in
              semper dignissim. In dapibus semper felis, non rutrum ex pulvinar
              a. Orci varius natoque penatibus et magnis dis parturient montes,
              nascetur ridiculus mus. Quisque ornare velit.
            </p>
            <Table
              striped
              bordered
              hover
              className="text-center"
              variant="dark"
            >
              <thead>
                <tr>
                  <th className=" text-center" colSpan={3} bg="dark">
                    Contact Details
                  </th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td>
                    <ImPhone />
                  </td>
                  <td>Phone</td>
                  <td>090078601</td>
                </tr>
                <tr>
                  <td>
                    <AiFillFacebook />
                  </td>
                  <td>Facebook</td>
                  <td>MarkZingerburger@Fb.com</td>
                </tr>
                <tr>
                  <td>
                    <CgMail />
                  </td>
                  <td>Email</td>
                  <td>@cuilahore.edu.pk</td>
                </tr>
              </tbody>
            </Table>
          </Col>
          <Col md={6}>
            <Image
              src="images/library.jpg "
              style={{ width: "100%", height: "100%" }}
            />
          </Col>
        </Row>
      </Container>
    </>
  );
};

export default Contact;
