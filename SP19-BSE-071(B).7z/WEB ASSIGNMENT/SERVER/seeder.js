const mongoose = require("mongoose");
const dotenv = require("dotenv");
require("colors");
const connectDb = require("./config/config");
const Book = require("./models/bookModel");
const Books = require("./data/book-data");
const { bgGreen } = require("colors");

dotenv.config();
connectDb();

const importData = async () => {
  try {
    await Book.deleteMany();
    const sampleData = Books.map((book) => {
      return { ...book };
    });
    await Book.insertMany(sampleData);
    console.log("Data imported".bgGreen.white);
    process.exit();
  } catch (error) {
    console.log(`${error}`.bgRed.white);
    process.exit(1);
  }
};

const dataDEstroy = () => {};
if (process.argv[2] === "-d") {
  dataDestroy();
} else {
  importData();
}
