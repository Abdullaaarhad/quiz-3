import axios from "axios";
export const registerUser = () => async (dispatch) => {
  dispatch({ type: "USER_REGISTER_REQUEST" });
  try {
    const res = await axios.post("api/user/register");
  } catch (error) {}
};
