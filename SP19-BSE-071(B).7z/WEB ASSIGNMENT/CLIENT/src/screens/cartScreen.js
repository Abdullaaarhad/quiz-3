import React from "react";
import { Container, Row, Col } from "react-bootstrap";

const cartScreen = () => {
  return (
    <>
      <Container>
        <Row>
          <Col md={6}>
            <h1>Cart Items</h1>
          </Col>
          <Col md={4}></Col>
        </Row>
      </Container>
    </>
  );
};

export default cartScreen;
