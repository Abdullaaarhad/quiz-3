import React from "react";
import { Container, Row, Col } from "react-bootstrap";

const About = () => {
  return (
    <>
      <Container style={{ marginTop: "50px" }}>
        <h1>who we are</h1>
        <p>
          Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus in
          orci et nulla consequat ornare. Etiam auctor ligula lectus, non
          vehicula dui maximus ac. Cras eu aliquam tellus, et rhoncus ante.
          Donec sit amet eleifend nulla. Fusce ut nunc ut diam consectetur
          lobortis. Pellentesque eu interdum ipsum, in mattis odio. Aliquam et
          odio vitae erat maximus dictum. Aliquam neque odio, sollicitudin quis
          quam a, iaculis pulvinar leo. Vestibulum iaculis eu sem sit amet
          tristique. Phasellus accumsan luctus nibh vitae luctus. Sed et
          venenatis risus. Praesent molestie erat non dapibus facilisis.
        </p>
        <h1> Our special</h1>
        <Row>
          <Col md={6}>
            <p>
              Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus
              in orci et nulla consequat ornare. Etiam auctor ligula lectus, non
              vehicula dui maximus ac. Cras eu aliquam tellus, et rhoncus ante.
              Donec sit amet eleifend nulla. Fusce ut nunc ut diam consectetur
              lobortis. Pellentesque eu interdum ipsum, in mattis odio. Aliquam
              et odio vitae erat maximus dictum. Aliquam neque odio,
              sollicitudin quis quam a, iaculis pulvinar leo. Vestibulum iaculis
              eu sem sit amet tristique. Phasellus accumsan luctus nibh vitae
              luctus. Sed et venenatis{" "}
            </p>
          </Col>
          <Col md={6}>
            Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus
            in orci et nulla consequat ornare. Etiam auctor ligula lectus, non
            vehicula dui maximus ac. Cras eu aliquam tellus, et rhoncus ante.
            Donec sit amet eleifend nulla. Fusce ut nunc ut diam consectetur
            lobortis. Pellentesque eu interdum ipsum, in mattis odio. Aliquam et
            odio vitae erat maximus dictum. Aliquam neque odio, sollicitudin
            quis quam a, iaculis pulvinar leo. Vestibulum iaculis eu sem sit
            amet tristique. Phasellus accumsan luctus nibh vitae luctus. Sed et
            venenatis
          </Col>
          <Row>
            <h1>Our Authors</h1>
            <Col md={3}>
              Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus
              in orci et nulla consequat ornare. Etiam auctor ligula lectus, non
              vehicula dui maximus ac. Cras eu aliquam tellus, et rhoncus ante.
              Donec sit amet eleifend nulla. Fusce ut nunc ut diam consectetur
              lobortis. Pellentesque eu interdum ipsum, in mattis odio. Aliquam
              et odio vitae erat maximus dictum. Aliquam neque odio,
              sollicitudin quis quam a, iaculis pulvinar leo. Vestibulum iaculis
              eu sem sit amet tristique. Phasellus accumsan luctus nibh vitae
              luctus. Sed et venenatis
            </Col>
            <Col md={3}>
              Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus
              in orci et nulla consequat ornare. Etiam auctor ligula lectus, non
              vehicula dui maximus ac. Cras eu aliquam tellus, et rhoncus ante.
              Donec sit amet eleifend nulla. Fusce ut nunc ut diam consectetur
              lobortis. Pellentesque eu interdum ipsum, in mattis odio. Aliquam
              et odio vitae erat maximus dictum. Aliquam neque odio,
              sollicitudin quis quam a, iaculis pulvinar leo. Vestibulum iaculis
              eu sem sit amet tristique. Phasellus accumsan luctus nibh vitae
              luctus. Sed et venenatis
            </Col>
            <Col md={3}>
              Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus
              in orci et nulla consequat ornare. Etiam auctor ligula lectus, non
              vehicula dui maximus ac. Cras eu aliquam tellus, et rhoncus ante.
              Donec sit amet eleifend nulla. Fusce ut nunc ut diam consectetur
              lobortis. Pellentesque eu interdum ipsum, in mattis odio. Aliquam
              et odio vitae erat maximus dictum. Aliquam neque odio,
              sollicitudin quis quam a, iaculis pulvinar leo. Vestibulum iaculis
              eu sem sit amet tristique. Phasellus accumsan luctus nibh vitae
              luctus. Sed et venenatis
            </Col>
          </Row>
        </Row>
      </Container>
    </>
  );
};

export default About;
