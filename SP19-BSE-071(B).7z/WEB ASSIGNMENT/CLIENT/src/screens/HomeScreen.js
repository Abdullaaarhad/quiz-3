import React, { useEffect } from "react";
import Allbooks from "../book-data";
import { useDispatch, useSelector } from "react-redux";
import { Container, Row, Col } from "react-bootstrap";
import { getAllBooks } from "../Actions/bookAction";
import Book from "../components/Book";

const HomeScreen = () => {
  const dispatch = useDispatch();
  const bookstate = useSelector((state) => state.getAllBookReducer);
  const { loading, books, error } = bookstate;
  useEffect(() => {
    dispatch(getAllBooks());
  }, [dispatch]);

  return (
    <>
      <Container>
        {loading ? (
          <h1>Loading...</h1>
        ) : (
          <Row>
            {Allbooks.map((book) => (
              <Col md={4}>
                <Book book={book} />
              </Col>
            ))}
          </Row>
        )}
      </Container>
    </>
  );
};

export default HomeScreen;
