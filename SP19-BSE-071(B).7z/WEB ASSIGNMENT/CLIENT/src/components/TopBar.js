import React from "react";
import { Navbar, Nav, Container } from "react-bootstrap";
import { LinkContainer } from "react-router-bootstrap";
import { MdLocalOffer } from "react-icons/md";
const TopBar = () => {
  return (
    <>
      <Navbar bg="sm" variant="warning" expand="lg">
        <Container fluid>
          <h6 classname="text-light">
            <MdLocalOffer classname="text-warning" /> &nbsp;&nbsp; Free home
            delivery
          </h6>
          <Nav classname="ms-auto">
            <LinkContainer to="/Home" activeClassName>
              <Nav.Link>Home</Nav.Link>
            </LinkContainer>
            <LinkContainer to="/about" activeClassName>
              <Nav.Link>About us</Nav.Link>
            </LinkContainer>
            <LinkContainer to="/contact" activeClassName>
              <Nav.Link>Contact us</Nav.Link>
            </LinkContainer>
            <LinkContainer to="/Terms" activeClassName>
              <Nav.Link>T and C</Nav.Link>
            </LinkContainer>
          </Nav>
        </Container>
      </Navbar>
    </>
  );
};

export default TopBar;
