import axios from "axios";

export const getAllBooks = () => async (dispatch) => {
  dispatch({ type: "GET_BOOKS_REQUEST" });
  try {
    const res = await axios.get("/api/books/getAllBooks");
    console.log(res);
    dispatch({ type: "GET_BOOKS_SUCCESS", payload: res.data });
  } catch (err) {
    dispatch({ type: "GET_BOOKS_FAILURE", payload: err });
  }
};
