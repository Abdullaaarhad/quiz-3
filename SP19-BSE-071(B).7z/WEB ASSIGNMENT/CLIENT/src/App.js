import "./App.css";
import { Container } from "react-bootstrap";
import { BrowserRouter, Route, Switch } from "react-router-dom";
import TopBar from "./components/TopBar";
import About from "./components/About";
import Contact from "./components/Contact";
import Policy from "./components/Policy";
import NavBar from "./components/NavBar";
import HomeScreen from "./screens/HomeScreen";
import Register from "./screens/Register";
import Login from "./screens/Login";
import cartScreen from "./screens/cartScreen";

function App() {
  return (
    <BrowserRouter>
      <TopBar />
      <NavBar />
      <Switch>
        <Route path="/Cart" component={cartScreen} exact />
        <Route path="/Submit" component={Login} exact />
        <Route path="/Login" component={Login} exact />
        <Route path="/Register" component={Register} exact />
        <Route path="/about" component={About} exact />
        <Route path="/contact" component={Contact} exact />
        <Route path="/Terms" component={Policy} exact />
        <Route path="/Home" component={HomeScreen} exact />
      </Switch>
    </BrowserRouter>
  );
}

export default App;
