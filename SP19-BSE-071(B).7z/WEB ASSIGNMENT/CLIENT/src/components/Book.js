import React, { useState } from "react";
import { Card, Button, Row, Col, Modal } from "react-bootstrap";
import { useDispatch, useSelector } from "react-redux";
import { addToCart } from "../Actions/carAction";

const Book = ({ book }) => {
  const [varient, setVarient] = useState("season1");
  const [quantity, setQuantity] = useState(1);
  const [show, setShow] = useState(false);

  const dispatch = useDispatch();
  const addToCartHandler = () => {
    dispatch(addToCart(book, varient, quantity));
  };

  const handleClose = () => setShow(false);
  const handleShow = () => setShow(true);
  return (
    <>
      <Card style={{ width: "18rem", marginTop: "30px" }}>
        <Card.Img
          variant="top"
          src={book.image}
          style={{ height: "280px", width: "260px", cursor: "pointer" }}
          onClick={handleShow}
        />

        <Card.Body>
          <Card.Title>{book.name}</Card.Title>
          ---------------------------------------
          <Card.Text>
            <Row>
              <Col md={6}>
                <h6>Varient</h6>
                <select
                  value={varient}
                  onChange={(e) => setVarient(e.target.value)}
                >
                  {book.varients.map((varient) => (
                    <option>{varient} </option>
                  ))}
                </select>
              </Col>
              <Col md={6}>
                <h6> Quantity</h6>
                <select
                  value={quantity}
                  onChange={(e) => setQuantity(e.target.value)}
                >
                  {[...Array(10).keys()].map((v, i) => (
                    <option value={i + 1}>{i + 1}</option>
                  ))}
                </select>
              </Col>
            </Row>
          </Card.Text>
          <Row>
            <Col md={6}>Price: {book.prices[0][varient] * quantity} $</Col>
            <Col md={6}>
              <Button onClick={addToCart} className="bg-dark text-white">
                Add to cart
              </Button>
            </Col>
          </Row>
        </Card.Body>
      </Card>
      {/*modal*/}
      <Modal show={show} onHide={handleClose}>
        <Modal.Header closeButton>
          <Modal.Title>{book.name}</Modal.Title>
        </Modal.Header>
        <Modal.Body>{book.description}</Modal.Body>
      </Modal>
    </>
  );
};

export default Book;
