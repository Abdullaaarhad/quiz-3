const books = [
  {
    name: "Harry Potter",
    varients: ["season1", "season2", "season3"],
    prices: [
      {
        season1: 99,
        season2: 199,
        season3: 399,
      },
    ],
    category: "Fiction",
    image: "/images/HP.jpg",
    description: "Step Into Hogwarts",
  },
  {
    name: "Marvel",
    varients: ["season1", "season2", "season3"],
    prices: [
      {
        season1: 229,
        season2: 399,
        season3: 599,
      },
    ],
    category: "Comic",
    image: "/images/Marvel.jpg",
    description: "Become a Sperhero",
  },
  {
    name: "Pakistan Studies",
    varients: ["season1", "season2", "season3"],
    prices: [
      {
        season1: 180,
        season2: 290,
        season3: 460,
      },
    ],
    category: "Fiction",
    description: "Learn about your Country",
    image: "/images/PS.jpg",
  },
  {
    name: "HTML",
    varients: ["season1", "season2", "season3"],
    prices: [
      {
        season1: 249,
        season2: 349,
        season3: 599,
      },
    ],
    category: "Study",
    image: "/images/html.jpg",
    description: "Learn HTML",
  },
  {
    name: "Stepehen king",
    varients: ["season1", "season2", "season3"],
    prices: [
      {
        season1: 320,
        season2: 580,
        season3: 800,
      },
    ],
    category: "Horror",
    image: "/images/IT.jpg",
    description: "Hello devil, its ya boy",
  },
  {
    name: "Cosmos",
    varients: ["season1", "season2", "season3"],
    prices: [
      {
        season1: 250,
        season2: 380,
        season3: 500,
      },
    ],
    category: "Space",
    image: "/images/cosmos.jpg",
    description: "Learn about space",
  },
];

export default books;
